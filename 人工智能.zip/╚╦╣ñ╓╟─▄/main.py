from evaluation import Loader, Cleaner, Splitter
from pathlib import Path
import json

if __name__ == '__main__':
    filenames = [Path(f'documents/doc {k + 1}.html') for k in range(5)]

    loader = Loader()
    cleaner = Cleaner()
    splitter = Splitter()

    data = []

    for path in filenames:
        content = loader(path)
        content = cleaner(content)
        chunks = splitter(content)
        doc = {'name': path.name, 'data': []}
        for chunk in chunks:
            doc['data'].append(chunk)
        data.append(doc)

    with open('dataset.json', 'w', encoding='UTF-8') as file:
        json.dump(data, file, ensure_ascii=False)

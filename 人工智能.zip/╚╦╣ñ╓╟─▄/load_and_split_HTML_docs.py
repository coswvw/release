import html2text
import re
from langchain_text_splitters import (
    MarkdownTextSplitter,
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter)

from dataclasses import dataclass

from pathlib import Path

import json


@dataclass
class Chunk:
    content: str


class Loader(object):

    def __init__(self, signature: str = 'HTML'):
        self._signature = signature
        self._converter = html2text.HTML2Text()
        converter.ignore_links = True
        converter.ignore_images = True

    def __call__(self, path: Path) -> str:
        with open(path, mode='r', encoding='UTF-8') as file:
            content = file.read()
        return self._converter.handle(content)


class Cleaner(object):

    def __init__(self, signature: str = 'HTML'):
        self._signature = signature

    def __call__(self, content: str) -> str:
        return ''


class Splitter(object):

    def __init__(self, signature: str = 'HTML'):
        self._signature = signature

    def __call__(self, content: str) -> str:
        return ''


class Pipeline(object):

    def __init__(self):
        pass

    def __call__(self, *args, **kwargs):
        pass

    def attach(self, component: Loader | Cleaner | Splitter):
        return self


def save_dataset(path: Path, dataset):
    with open(path, 'w', encoding='UTF-8'):
        json.dump(dataset, file)


if __name__ == '__main__':
    with open(Path(r'documents/doc 2.html'), mode='r', encoding='UTF-8') as file:
        text = file.read()

    converter = html2text.HTML2Text()
    converter.ignore_links = True
    converter.ignore_images = True
    converter.ignore_tables = True

    text = converter.handle(text)
    print(text)

    text = text.strip()
    text = re.sub(r'\s+', ' ', text)
    # text = re.sub(r'\n+', ' ', text)
    print('')
    print(text)

    print('\n===================================================================================\n')

    splitter = MarkdownTextSplitter(chunk_size=300, chunk_overlap=90)
    docs = splitter.split_text(text)

    for doc in docs:
        print('-----------------------------------------------------------------------------------')
        print(doc)

    # markdown_splitter = MarkdownHeaderTextSplitter(
    #     headers_to_split_on=[
    #         ("#", "Header 1"),
    #         ("##", "Header 2"),
    #         ("###", "Header 3"),
    #         ("####", "Header 4")])
    # docs = markdown_splitter.split_text(text)
    #
    # for doc in docs:
    #     print('-----------------------------------------------------------------------------------')
    #     print(doc.page_content)

    # text_splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50,
    #                                                separators=[
    #                                                    "\n\n",
    #                                                    "\n",
    #                                                    " ",
    #                                                    ".",
    #                                                    ",",
    #                                                    "\u200b",  # Zero-width space
    #                                                    "\uff0c",  # Fullwidth comma
    #                                                    "\u3001",  # Ideographic comma
    #                                                    "\uff0e",  # Fullwidth full stop
    #                                                    "\u3002",  # Ideographic full stop
    #                                                    "",
    #                                                ])

    # docs = text_splitter.split_text(text)
    #
    # for doc in docs:
    #     print('-----------------------------------------------------------------------------------')
    #     print(doc)

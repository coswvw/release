import html2text
import re
from langchain_text_splitters import (
    MarkdownTextSplitter,
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter)

from dataclasses import dataclass

from pathlib import Path

import json

from typing import List


class Loader(object):

    def __init__(self):
        self._converter = html2text.HTML2Text()
        self._converter.ignore_links = True
        self._converter.ignore_images = True

    def __call__(self, path: str | Path) -> str:
        with open(path, mode='r', encoding='UTF-8') as file:
            content = file.read()
        content = self._converter.handle(content)
        return content


class Cleaner(object):

    def __init__(self):
        pass

    def __call__(self, content: str) -> str:
        content = re.sub(r'\s+', ' ', content.strip())
        return content


class Splitter(object):

    def __init__(self):
        self._splitter = MarkdownTextSplitter(chunk_size=500, chunk_overlap=100)

    def __call__(self, content: str) -> List[str]:
        return self._splitter.split_text(content)

# class Pipeline(object):
#
#     def __init__(self):
#         self._load = None
#         self._components = []
#
#     def __call__(self, path: str | Path):
#         content = self._load(path)
#         for component in self._components:
#             content =
#
#     def attach(self, component: Loader | Cleaner | Splitter):
#         if self._components is None:
#             assert isinstance(component, Loader)
#
#         self._components.append(component)
#         return self

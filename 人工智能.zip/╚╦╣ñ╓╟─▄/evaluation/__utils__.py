from openai import OpenAI


class LLM(object):

    def __init__(self):
        self._client = OpenAI(
            api_key=None,
            base_url='https://api.chatanywhere.tech')

    def query(self, prompt: str):
        result = self._client.chat.completions.create(
            messages=[
                {
                    "role": "user",
                    "content": prompt,
                }
            ],
            model="gpt-4", max_tokens=1024)
        return result.choices[0].message.content
